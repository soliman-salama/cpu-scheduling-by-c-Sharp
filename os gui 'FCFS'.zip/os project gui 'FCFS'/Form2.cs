﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace os_project_gui
{

    public partial class Form2 : Form
    {
        Form1 f1;
        public Form2(Form1 frm)
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
            f1 = frm;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            f1.process.Add(textBox1.Text);
            f1.arrival.Add(int.Parse(textBox2.Text));
            f1.duration.Add(int.Parse(textBox3.Text));
            f1.dur += int.Parse(textBox3.Text);
           // Form1 pnn = new Form1(this);

            this.Close();

        }

    }
}
