﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace os_project_gui
{

    public partial class Form1 : Form
    {
       public class color2
       {
            public int r, g, b;
       }
        /*public class color2
        {
            public string pr;
        }*/
        int draw = 0, sim = 0, time = 1,  timer2 = 0;
        float avg_wt = 0, avg_tat = 0;
        Timer tt = new Timer();
        Random rr = new Random();
        /* List<TextBox> process = new List<TextBox>();
         List<TextBox> arrival = new List<TextBox>();
         List<TextBox> duration = new List<TextBox>();*/
       public List<color2> clr = new List<color2>();
       public List<string> process = new List<string>();
       public List<string> simulation = new List<string>();
       public List<int> arrival = new List<int>();
       public List<int> duration = new List<int>();
       public List<int> wt = new List<int>();
       public List<int> tat = new List<int>();
        int localy = 200, localx = -1;
        public int dur = 0;
        public Form1()
        {

           
            this.StartPosition = FormStartPosition.CenterScreen;
            tt.Tick += Tt_Tick;
            tt.Start();
            InitializeComponent();
           WindowState =FormWindowState.Maximized;
            
            
        }

        private void Tt_Tick(object sender, EventArgs e)
        {

            if (process.Count != 0)
                Text = process[process.Count - 1];

            /* if(process.Count==3)
             {
                 MessageBox.Show("it work");
             }*/

            if (sim == dur&&sim!=0)
            {
                localx = 100;
                if (time % 10 == 0)
                    timer2++;
            }
            if (draw != 0)
            {
                time++;
                drawscene(CreateGraphics());
            }
        
            if (time % 10 == 0 && simulation.Count > sim)
            {
                sim++;
            }
          

           
        }
        void show()
        {
            for (int i = 0; i < process.Count; i++)
            {

                for (int p = 0; p < duration[i]; p++)
                {
                    simulation.Add(process[i]);
                }

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 pnn = new Form2(this);
            pnn.Show();
        }

        int mainx = 100, mainy = 100;

        private void button2_Click(object sender, EventArgs e)
        {

            draw = 1;
            create_color();
            button1.Enabled = false;
            sort();
            show();
            findWaitingTime();
            findTurnAroundTime();
            

        }

        void drawscene(Graphics g)
        {
           // Color.FromArgb(255, 255, 255);
            int x = 100, y = 100;
            /* for(int i=0;i<simulation.Count;i++)
               {

                   Brush br = new SolidBrush(Color.FromArgb(clr[i].r, clr[i].g, clr[i].b));
                   for (int p=0;p<duration[i];p++)
                   {
                       g.FillRectangle(br, x, y, 20, 60);
                       g.DrawString(process[i], this.Font, Brushes.Red, x , y + 20);
                       x += 22;

                   }
               }*/

            int pos = 0;
            Brush br = new SolidBrush(Color.FromArgb(clr[pos].r, clr[pos].g, clr[pos].b));
            Font fnt = new Font(Font.FontFamily, 16);
            for (int p = 0; p < sim; p++) 
            {
                if (p != 0 && simulation[p] != simulation[p - 1]) //color change
                {
                    pos++;
                    br = new SolidBrush(Color.FromArgb(clr[pos].r, clr[pos].g, clr[pos].b));
                }

                g.FillRectangle(br, x, y, 40, 100);
                g.DrawString(simulation[p],fnt, Brushes.Red, x, y + 20);
                x += 44;
                if(x>=1200)
                {
                    x = 100;
                    y += 120;
                    localy = y + 120;
                }
            }
            
           if(localx!=-1)
           {
                g.DrawString("                  wt          tat          b_time             arrival", fnt,Brushes.Black,localx,localy); 

               for(int i=0;i<process.Count;i++)
               {
                    br = new SolidBrush(Color.FromArgb(clr[i].r, clr[i].g, clr[i].b));
                    string st = process[i]+"                "+wt[i]+"           "+tat[i]+"             "+duration[i]+"                       "+arrival[i];
                    g.DrawString(st, fnt, br, localx, localy+50);
                    localy += 30;
                    System.Threading.Thread.Sleep(2300);
               }
                Text = "" + avg_wt;
                //float avgwt = (float)avg_wt /3;
                //float avgtat = (float)avg_tat / process.Count;
                localy += 90;
                g.DrawString("avg waiting time = "+avg_wt+"& avg turn around time is  "+avg_tat, fnt, Brushes.Red, localx, localy);
                tt.Stop();
           }

        }

        void create_color()
        {
            int r, g, b;
            for(int i=0;i<process.Count;i++)
            {
                r = rr.Next(0, 255);
                g = rr.Next(0, 255);
                b = rr.Next(0, 255);
                color2 pnn = new color2();
                pnn.r = r;
                pnn.g = g;
                pnn.b = b;
                clr.Add(pnn);
            }
            
        }


        void findWaitingTime()
        {

            /* process num = i:
       wt[i] = (duration[0] + duration[1] + ......duration[i - 1]) - arrival[i]*/


            wt.Add(0);
            int wttot = 0;
            for (int i = 0; i < process.Count; i++)
            {
                wttot = 0;
                for(int z=0; z<i; z++)
                {
                    wttot += duration[z];
                }
                if (i != 0)
                {

                    wt.Add(wttot - arrival[i]);
                }
                
            }
            //avg waiting time
            int tot = 0;
            for(int i=0;i<wt.Count;i++)
            {
                tot += wt[i];
            }
           // MessageBox.Show("" + wt);
            avg_wt = (float) tot /(float) process.Count;
        }

        void findTurnAroundTime()//depend on find wt first
        {
            for (int i = 0; i < process.Count; i++)
            {
                tat.Add(duration[i] + wt[i]);
            }
            //avg turn around time
            int tot = 0;
            for (int i = 0; i < tat.Count; i++)
            { 
                tot += tat[i];
            }
            avg_tat = (float)tot / (float)process.Count;
        }






        void sort()
        {
            int tempint;
            string temp;
            for(int i=0;i<process.Count;i++)
            {
                for(int z=i+1;z<process.Count;z++)
                {
                    if(arrival[z]<arrival[i])
                    {
                        //swap arrival
                        tempint = arrival[z];
                        arrival[z] = arrival[i];
                        arrival[i] = tempint;

                        //swap process

                        temp = process[z];
                        process[z] = process[i];
                        process[i] = temp;

                        //swap duration 

                        tempint = duration[z];
                        duration[z] = duration[i];
                        duration[i] = tempint;
                        
                    }
                }
            }
        }

    }
}
